
Project RDK3:
PCB dimensions 96.1x48.1mm.
6 Layers.
Thickness: 1.55mm FR4.
Mask color: Purple.
Silkscreen color: White.
Finish: Immersion Gold.
Vias: Tented.